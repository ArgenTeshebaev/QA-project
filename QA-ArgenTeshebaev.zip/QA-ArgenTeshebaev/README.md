# QA-Midterm-Autotests

## Running tests

npm run login

npm run create

npm run view

npm run edit

npm run search
